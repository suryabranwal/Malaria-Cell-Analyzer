# Malaria-Cell-Analyzer
A Machine Learning web app using django that analyses human cell images for "Malaria causing parasite"

